const fs = require('fs');

function extractMovieDetails(title) {
  const regex = /^(.*?)\s+(FRENCH|ENGLISH|TRUEFRENCH|VOSTFR|MULTi|Multi|ENG|MULTI|VO)\s+(.*?)\s+(.*?)\s*(\(\d{4}(?:-\d{4})?\)|\d{4})$/;
  const matches = title.match(regex);

  if (matches) {
    const completeTitle = matches[1];
    const language = matches[2];
    const fileType = matches[3];
    const quality = matches[4];
    const year = matches[5];

    return {
      completeTitle,
      language,
      fileType,
      quality,
      year
    };
  }

  return null;
}

function writeDataToCSV(data, filename) {
  const rows = data.map(row => row.join('|'));

  const csvContent = rows.join('\n');

  fs.appendFileSync(filename, csvContent + '\n', 'utf8');
}

function createNewMovieId(existingMovies) {
  if (existingMovies.length === 0) {
    return 1;
  }

  const lastMovieId = existingMovies[existingMovies.length - 1].id;
  return lastMovieId + 1;
}

function findExistingMovieId(existingMovies, movieTitle, movieYear) {
  const existingMovie = existingMovies.find(
    movie => movie.title === movieTitle && movie.year === movieYear
  );

  return existingMovie ? existingMovie.id : null;
}

function readMoviesCSV(csvFilename) {
  const csvData = fs.readFileSync(csvFilename, 'utf8');
  const lines = csvData.split('\n').filter(Boolean);
  const headers = lines[0].split(',');

  const movies = [];

  for (let i = 1; i < lines.length; i++) {
    const line = lines[i];
    const [link,title,language,format,year,size,seeders,leechers] = line.split('|');

    if (!title) {
      console.log('empty title', line);
    }
    const movieDetails = extractMovieDetails(title);
    // {
    //   completeTitle,
    //   language,
    //   fileType,
    //   quality,
    //   year
    // }

    if (movieDetails) {
      movies.push({
        link,
        title: movieDetails.completeTitle,
        year: movieDetails.year,
        language: movieDetails.language,
        fileType: movieDetails.fileType,
        quality: movieDetails.quality,
        size, seeders, leechers
      });
    } else {
      console.log('is null for title', title);
    }
  }

  return movies;
}

function processMovies(movies, separateMoviesFilename, torrentsFilename) {
  const existingMovies = [];

  if (fs.existsSync(separateMoviesFilename)) {
    const separateMoviesData = fs.readFileSync(separateMoviesFilename, 'utf8');
    const separateMoviesLines = separateMoviesData.split('\n').filter(Boolean);

    for (let i = 1; i < separateMoviesLines.length; i++) {
      const line = separateMoviesLines[i];
      const values = line.split(',');

      const id = parseInt(values[0]);
      const title = values[1];
      const year = values[2];

      existingMovies.push({
        id,
        title,
        year
      });
    }
  }

  const separateMoviesData = [];
  const torrentsData = [];

  for (const movie of movies) {
    const { title, year } = movie;

    const existingMovieId = findExistingMovieId(existingMovies, title, year);
    let movieId;

    if (existingMovieId) {
      movieId = existingMovieId;
    } else {
      movieId = createNewMovieId(existingMovies);
      existingMovies.push({ id: movieId, title, year });

      separateMoviesData.push([movieId, title, year]);
    }

    torrentsData.push([
      movie.link, movieId, movie.size, movie.seeders, movie.leechers, movie.fileType, movie.quality]);
  }

  writeDataToCSV(separateMoviesData, separateMoviesFilename);
  writeDataToCSV(torrentsData, torrentsFilename);
}

function main() {
  const csvFilename = 'files/movies.csv';
  const separateMoviesFilename = 'files/separate_movies.csv';
  const torrentsFilename = 'files/torrents.csv';

  const movies = readMoviesCSV(csvFilename);
  console.log('lines count', movies.length);

  if (movies.length === 0) {
    console.log('No movies found in the CSV file.');
    return;
  }

  processMovies(movies, separateMoviesFilename, torrentsFilename);

  console.log('Processing complete.');
}

// Run the main function
main();