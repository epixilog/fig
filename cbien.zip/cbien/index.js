const axios = require('axios');
const cheerio = require('cheerio');
const fs = require('fs');

// Function to extract movie details from a table row
function extractMovieDetails(row) {
  const $ = cheerio.load(row);

  const link = $('a.titre').attr('href');
  const title = $('a.titre').attr('title');
  const size = $('div.poid').text().trim();
  const seeders = $('div.up span.seed_ok').text();
  const leechers = $('div.down').text();

  // Extracting language, format, and year from the title
  const titleSegments = title.split(' ');
  const language = titleSegments.find(segment => segment.toUpperCase() === segment);
  const format = titleSegments.slice(1, -1).join(' ');
  const year = titleSegments.slice(-1)[0];

  return {
    link,
    title,
    language,
    format,
    year,
    size,
    seeders,
    leechers
  };
}

// Function to scrape a batch of pages
async function scrapePagesBatch(pageUrls) {
    const requests = pageUrls.map(url => axios.get(url));
  
    try {
      const responses = await Promise.allSettled(requests);
      const movies = [];
      const errors = [];
  
      responses.forEach((response, index) => {
        if (response.status === 'fulfilled') {
          const { data } = response.value;
          const $ = cheerio.load(data);
          const movieRows = $('div#gauche table tr:has(td)');
  
          movieRows.each((_, row) => {
            const movie = extractMovieDetails(row);
            movies.push(movie);
          });
        } else {
          const pageUrl = pageUrls[index];
          errors.push(pageUrl);
          console.error(`Failed to process page: ${pageUrl}`);
        }
      });
  
      return {
        movies,
        errors
      };
    } catch (error) {
      console.error('Error:', error);
      return {
        movies: [],
        errors: pageUrls
      };
    }
  }

// Function to scrape the page
async function scrapePage(baseUrl, url) {
  try {
    const response = await axios.get(url);
    const $ = cheerio.load(response.data);

    const movieRows = $('div#gauche table tr:has(td)');

    const movies = [];

    // Extract movie details from each row
    movieRows.each((_, row) => {
      const movie = extractMovieDetails(row);
      movies.push(movie);
    });

    const nextPageUrl = $('ul.pagination li:last-child a').attr('href');
    const nextPageFullUrl = nextPageUrl ? `${baseUrl}${nextPageUrl}` : null;

    return {
      movies,
      nextPageUrl: nextPageFullUrl
    };
  } catch (error) {
    console.error('Error:', error);
    return {
      movies: [],
      nextPageUrl: null
    };
  }
}

// Function to write errors to a file
function writeErrorsToFile(errors, filename) {
    const errorContent = errors.join('\n');
    fs.appendFileSync(filename, errorContent + '\n', 'utf8');
  }

// Function to write data to a CSV file
function writeDataToCSV(data, filename) {
  const headers = [
    'Link',
    'Title',
    'Language',
    'Format',
    'Year',
    'Size',
    'Seeders',
    'Leechers'
  ];

  const rows = [headers.join('|')];

  data.forEach(movie => {
    const row = [
      movie.link,
      movie.title,
      movie.language,
      movie.format,
      movie.year,
      movie.size,
      movie.seeders,
      movie.leechers
    ];
    rows.push(row.join('|'));
  });

  const csvContent = rows.join('\n');

  fs.appendFile(filename, csvContent, 'utf8', err => {
    if (err) {
      console.error('Error writing to CSV:', err);
    } else {
      console.log(`Data successfully written to ${filename}`);
    }
  });
}

// Main function
async function main() {
  const baseUrl = 'https://www.cpasbien.sk';
  const initialPageUrl = `${baseUrl}/torrents/films`;
  const csvFilename = 'files/movies.csv';
  let currentPageUrl = initialPageUrl;

  let moviesCount = 0;
  let totalPages = 0;

  // Check if the CSV file exists
  if (fs.existsSync(csvFilename)) {
    // Read the existing CSV file to get the progress
    const existingData = fs.readFileSync(csvFilename, 'utf8');
    const existingRows = existingData.split('\n');
    moviesCount = existingRows.length - 1; // Subtract 1 for the header row

    if (moviesCount > 0) {
      console.log(`Resuming from movie count: ${moviesCount}`);
    } else {
      console.log(`No existing data found. Starting from scratch.`);
    }
  } else {
    console.log(`No existing data found. Starting from scratch.`);
    const headers = [
      'Link',
      'Title',
      'Language',
      'Format',
      'Year',
      'Size',
      'Seeders',
      'Leechers'
    ];
    fs.writeFileSync(csvFilename, headers.join(',') + '\n');
  }

  while (currentPageUrl) {
    try {
      console.log(`Scraping page: ${currentPageUrl}`);
      const { movies, nextPageUrl } = await scrapePage(baseUrl, currentPageUrl);

      // Write the data to the CSV file
      writeDataToCSV(movies, csvFilename);

      moviesCount += movies.length;
      totalPages++;
      console.log(`Total movies processed: ${moviesCount}`);

      currentPageUrl = nextPageUrl;

      // Sleep for 1 second before making the next request
      await new Promise(resolve => setTimeout(resolve, 1000));
    } catch (error) {
      console.error('Error:', error);
      console.log(`Failed to process page: ${currentPageUrl}`);
      console.log(`Current movie count: ${moviesCount}`);
      console.log(`Total pages processed: ${totalPages}`);
      console.log(`To resume, run the script again.`);
      break;
    }
  }
}

// Main function
async function mainBatch(startPage = 1, batchSize = 5, targetPage = 16901) {
    const baseUrl = 'https://www.cpasbien.sk';
    const initialPage = startPage;
    const csvFilename = 'files/movies.csv';
    const errorsFilename = 'files/errors.txt';
  
    let currentPage = initialPage;
    let moviesCount = 0;
    let totalPages = 0;
  
    const headers = [
    'Link',
    'Title',
    'Language',
    'Format',
    'Year',
    'Size',
    'Seeders',
    'Leechers'
    ];
    fs.writeFileSync(csvFilename, headers.join('|') + '\n');
  
    // // Check if the errors file exists
    // if (!fs.existsSync(errorsFilename)) {
    //   fs.writeFileSync(errorsFilename, '', 'utf8');
    // }
  
    // const errors = fs.readFileSync(errorsFilename, 'utf8').split('\n').filter(Boolean);
    // const failedPages = [...errors];
  
    // while (failedPages.length > 0) {
    //   const batchPages = failedPages.splice(0, batchSize);
    //   const batchUrls = batchPages.map(page => `${baseUrl}/torrents/films/${page}`);
  
    //   console.log(`Scraping batch of pages: ${batchUrls.join(', ')}`);
    //   const { movies, errors } = await scrapePagesBatch(batchUrls);
  
    //   // Write the data to the CSV file
    //   writeDataToCSV(movies, csvFilename);
  
    //   moviesCount += movies.length;
    //   totalPages += batchUrls.length;
    //   console.log(`Total movies processed: ${moviesCount}`);
  
    //   // Write any errors to the errors file
    //   writeErrorsToFile(errors, errorsFilename);
    // }
  
    while (true) {
      const pageRange = Array.from({ length: batchSize }, (_, index) => currentPage + (index * 50));
      do {
        currentPage = pageRange[pageRange.length - 1];
        if (currentPage > targetPage) {
            pageRange.pop();
        } else {
            break;
        }
      } while(pageRange.length >= 1);

      if (pageRange.length <= 0) {
        break;
      }

      const pageUrls = pageRange.map(page => `${baseUrl}/torrents/films/${page}`);
  
      console.log(`Scraping batch of pages: ${pageUrls.join('\n')}`);
      const { movies, errors } = await scrapePagesBatch(pageUrls);
  
      // Write the data to the CSV file
      writeDataToCSV(movies, csvFilename);
  
      moviesCount += movies.length;
      totalPages += pageUrls.length;
      console.log(`Total movies processed: ${moviesCount}`);
  
      // Write any errors to the errors file
      writeErrorsToFile(errors, errorsFilename);
  
      if (errors.length > 0) {
        console.log(`Failed to process some pages. Retrying failed pages in the next batch.`);
        failedPages.push(...errors);
      }
  
      // Break the loop if we have processed the desired number of pages
      if (currentPage >= targetPage) {
        break;
      }
    }
  
    console.log(`Total pages processed: ${totalPages}`);
  }
  
  // Parse command-line arguments for start page and batch size
  const args = process.argv.slice(2);
  const startPage = parseInt(args[0]) || 1;
  const batchSize = parseInt(args[1]) || 5;
  
  // Run the scraper
  mainBatch(startPage, batchSize);

  
  
  

// Run the scraper
// main();



// async function unmain() {
//     console.log('lets go')
//  const movies = await scrapePage('https://www.cpasbien.sk/torrents/films')
//  console.log('movies', movies)
// }

// unmain()

